package ro.smartguardian.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.smartguardian.app.data.RecAction
import ro.smartguardian.app.data.formatSize
import ro.smartguardian.app.vpn.AdBlockVpnService

@Composable
fun DashboardScreen(vm: MainViewModel, goTo: (String) -> Unit, onAction: (RecAction) -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val blocked by AdBlockVpnService.blocked.collectAsStateWithLifecycle()
    val vpnOn by AdBlockVpnService.running.collectAsStateWithLifecycle()
    val days by vm.unusedDays.collectAsStateWithLifecycle()
    val unused = ui.apps.count { it.isUnused }
    val score = ui.health.score
    val label = when { score >= 85 -> "Excelent"; score >= 65 -> "Bun"; score >= 40 -> "Necesită atenție"; else -> "Critic" }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Appear(0) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.Shield, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    ScreenTitle("SmartPhone Guardian", "Protecție și optimizare, local pe telefon")
                }
            }
        }
        item {
            Appear(1) {
                GCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Scorul de sănătate al telefonului", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        if (ui.loading) CircularProgressIndicator(Modifier.padding(60.dp)) else HealthRing(score)
                        Spacer(Modifier.height(8.dp))
                        if (!ui.loading) Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Appear(2) {
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val d = ui.device
                    StatCard(
                        Icons.Rounded.Storage, "Spațiu ocupat", d?.let { "${(it.storageFraction * 100).toInt()}%" } ?: "–",
                        d?.let { "${formatSize(it.storageUsed)} din ${formatSize(it.storageTotal)}" } ?: "", MaterialTheme.colorScheme.secondary,
                        Modifier.weight(1f).fillMaxHeight()
                    ) { goTo("optimize") }
                    StatCard(
                        Icons.Rounded.Memory, "Memorie RAM", d?.let { "${(it.ramFraction * 100).toInt()}%" } ?: "–",
                        d?.let { "${formatSize(it.ramUsed)} din ${formatSize(it.ramTotal)}" } ?: "", MaterialTheme.colorScheme.primary,
                        Modifier.weight(1f).fillMaxHeight()
                    ) { goTo("optimize") }
                }
            }
        }
        item {
            Appear(3) {
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        Icons.Rounded.DeleteSweep, "Aplicații nefolosite", if (ui.hasUsage) "$unused" else "–",
                        if (ui.hasUsage) "de peste $days zile" else "necesită Acces la utilizare", Warn,
                        Modifier.weight(1f).fillMaxHeight()
                    ) { goTo("apps") }
                    StatCard(
                        Icons.Rounded.Block, "Reclame blocate", "$blocked",
                        if (vpnOn) "Protecție activă" else "Protecție oprită", if (vpnOn) Good else Bad,
                        Modifier.weight(1f).fillMaxHeight()
                    ) { goTo("ads") }
                }
            }
        }
        item { Appear(4) { Text("Recomandări de optimizare", fontSize = 18.sp, fontWeight = FontWeight.Bold) } }
        if (ui.health.recommendations.isEmpty() && !ui.loading) {
            item { GCard(Modifier.fillMaxWidth()) { Text("Totul arată bine. Nu ai nicio recomandare acum.") } }
        }
        items(ui.health.recommendations) { r ->
            GCard(Modifier.fillMaxWidth(), onClick = { onAction(r.action) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontWeight = FontWeight.SemiBold)
                        Text(r.detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (r.action != RecAction.NONE) Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }
    }
}
