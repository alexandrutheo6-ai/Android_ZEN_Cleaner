package ro.smartguardian.app.data

import android.content.Context
import ro.smartguardian.app.Notifier

/**
 * Detectează aplicațiile instalate după ultima verificare și trimite o notificare
 * cu avertizare (reclame / trackere / achiziții). Nu blochează instalarea.
 * Apelat: instant (receiver dinamic, cât timp procesul e activ), la fiecare 15 min (WorkManager) și la deschiderea aplicației.
 */
object InstallWatcher {
    @Synchronized
    fun check(ctx: Context) {
        val prefs = Prefs(ctx)
        val apps = AppScanner.userApps(ctx).associateBy { it.packageName }
        val known = prefs.knownPackages
        prefs.knownPackages = apps.keys
        if (known == null) return // prima rulare: doar memorăm lista
        val pm = ctx.packageManager
        for (pkg in apps.keys - known) {
            val label = pm.getApplicationLabel(apps.getValue(pkg)).toString()
            val report = AdDetector.analyze(ctx, pkg, label) ?: continue
            if (report.hasAds || report.trackers.isNotEmpty() || report.hasBilling) Notifier.warn(ctx, report)
        }
    }
}
