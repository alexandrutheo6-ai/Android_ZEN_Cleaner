package ro.smartguardian.app

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import ro.smartguardian.app.data.InstallWatcher
import ro.smartguardian.app.data.Prefs
import ro.smartguardian.app.vpn.AdBlockVpnService
import java.util.concurrent.TimeUnit

class GuardianApp : Application() {

    // Android 8+ nu livrează PACKAGE_ADDED către receivere din manifest, deci îl înregistrăm dinamic.
    private val installReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Thread { InstallWatcher.check(context.applicationContext) }.start()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannel(this)
        AdBlockVpnService.blocked.value = Prefs(this).blockedCount

        val filter = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        ContextCompat.registerReceiver(this, installReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        // Plasă de siguranță: verificare periodică (minim 15 min, limită Android) dacă procesul a fost oprit.
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "install-watch", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<InstallWatchWorker>(15, TimeUnit.MINUTES).build()
        )
    }
}
