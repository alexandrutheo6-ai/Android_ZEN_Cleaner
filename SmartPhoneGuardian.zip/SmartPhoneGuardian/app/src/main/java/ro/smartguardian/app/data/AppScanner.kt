package ro.smartguardian.app.data

import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import android.os.storage.StorageManager
import java.io.File

data class AppInfo(
    val packageName: String,
    val label: String,
    val sizeBytes: Long,
    /** null = necunoscut (fără Acces la utilizare), 0 = peste un an / niciodată */
    val lastUsed: Long?,
    val installTime: Long,
    val isDuplicate: Boolean,
    val isUnused: Boolean
)

/** Scanează aplicațiile instalate de utilizator. Aplicațiile de sistem NU sunt listate niciodată. */
object AppScanner {

    @Suppress("DEPRECATION")
    private fun defaultLauncher(ctx: Context): String? =
        ctx.packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName

    /** Aplicații instalate de utilizator, cu pictogramă de lansare; exclude sistemul, launcherul și aplicația noastră. */
    fun userApps(ctx: Context): List<ApplicationInfo> {
        val pm = ctx.packageManager
        val launcher = defaultLauncher(ctx)
        return pm.installedApps().filter { ai ->
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            !system && ai.packageName != ctx.packageName && ai.packageName != launcher &&
                pm.getLaunchIntentForPackage(ai.packageName) != null
        }
    }

    fun scan(ctx: Context, unusedDays: Int, hasUsage: Boolean): List<AppInfo> {
        val pm = ctx.packageManager
        val sm = ctx.getSystemService(StorageStatsManager::class.java)
        val lastUsed = if (hasUsage) lastUsedMap(ctx) else emptyMap()
        val threshold = System.currentTimeMillis() - unusedDays * 86_400_000L

        val raw = userApps(ctx).map { ai ->
            val install = pm.pkgInfo(ai.packageName, 0)?.firstInstallTime ?: 0L
            val lu: Long? = if (hasUsage) (lastUsed[ai.packageName] ?: 0L) else null
            AppInfo(
                packageName = ai.packageName,
                label = pm.getApplicationLabel(ai).toString(),
                sizeBytes = sizeOf(sm, ai, hasUsage),
                lastUsed = lu,
                installTime = install,
                isDuplicate = false,
                isUnused = lu != null && maxOf(lu, install) < threshold
            )
        }
        // Duplicate = mai multe aplicații cu același nume
        val dup = raw.groupBy { it.label.lowercase() }.filter { it.value.size > 1 }.keys
        return raw.map { it.copy(isDuplicate = it.label.lowercase() in dup) }
            .sortedByDescending { it.sizeBytes }
    }

    private fun sizeOf(sm: StorageStatsManager, ai: ApplicationInfo, hasUsage: Boolean): Long = try {
        if (!hasUsage) throw SecurityException()
        val st = sm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, Process.myUserHandle())
        st.appBytes + st.dataBytes
    } catch (e: Exception) {
        runCatching { File(ai.sourceDir).length() }.getOrDefault(0L)
    }

    private fun lastUsedMap(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val end = System.currentTimeMillis()
        val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, end - 365L * 86_400_000L, end)
        val m = HashMap<String, Long>()
        for (s in list.orEmpty()) m[s.packageName] = maxOf(m[s.packageName] ?: 0L, s.lastTimeUsed)
        return m
    }

    /** Timp petrecut în prim-plan în ultimele 7 zile (ms), per pachet. */
    fun weeklyUsage(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val end = System.currentTimeMillis()
        val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, end - 7L * 86_400_000L, end)
        val m = HashMap<String, Long>()
        for (s in list.orEmpty()) m[s.packageName] = (m[s.packageName] ?: 0L) + s.totalTimeInForeground
        return m
    }
}
