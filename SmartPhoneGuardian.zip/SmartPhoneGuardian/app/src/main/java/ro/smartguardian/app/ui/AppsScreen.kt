package ro.smartguardian.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.smartguardian.app.data.Perms
import ro.smartguardian.app.data.formatLastUsed
import ro.smartguardian.app.data.formatSize
import androidx.compose.ui.platform.LocalContext

@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val queue by vm.uninstallQueue.collectAsStateWithLifecycle()
    val days by vm.unusedDays.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }

    // Dezinstalare pe rând, prin dialogul oficial Android (cerut de sistem pentru fiecare aplicație)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.onUninstallResult() }
    LaunchedEffect(queue.firstOrNull()) {
        queue.firstOrNull()?.let {
            launcher.launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:$it")).putExtra(Intent.EXTRA_RETURN_RESULT, true))
        }
    }

    val shown = remember(ui.apps, filter) {
        when (filter) {
            1 -> ui.apps.filter { it.isUnused }
            2 -> ui.apps.filter { it.sizeBytes > 300L * 1024 * 1024 }
            3 -> ui.apps.filter { it.isDuplicate }
            else -> ui.apps
        }
    }
    val shownPkgs = shown.map { it.packageName }
    val allSelected = shown.isNotEmpty() && shownPkgs.all { it in selected }
    val chosen = ui.apps.filter { it.packageName in selected }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        ScreenTitle("Aplicații", "${ui.apps.size} instalate • aplicațiile de sistem nu sunt afișate")
        if (!ui.hasUsage) {
            Spacer(Modifier.height(8.dp))
            GCard(Modifier.fillMaxWidth(), onClick = { Perms.openUsageSettings(ctx) }) {
                Text("Acordă „Acces la utilizare”", fontWeight = FontWeight.SemiBold)
                Text("Fără el nu pot afla ultima utilizare și dimensiunea reală. Atinge pentru a deschide setările.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Toate", "Nefolosite", "Mari", "Duplicate").forEachIndexed { i, t ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { if (allSelected) vm.deselect(shownPkgs) else vm.select(shownPkgs) }, enabled = shown.isNotEmpty()) {
                Text(if (allSelected) "Deselectează toate" else "Selectează toate")
            }
            Text("${selected.size} selectate", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))

        if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shown.isEmpty() && !ui.loading) item { Text("Nicio aplicație în această categorie.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shown, key = { it.packageName }) { a ->
                GCard(Modifier.fillMaxWidth(), onClick = { vm.toggle(a.packageName) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Checkbox(a.packageName in selected, { vm.toggle(a.packageName) })
                        AppIcon(a.packageName)
                        Column(Modifier.weight(1f)) {
                            Text(a.label, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${formatSize(a.sizeBytes)} • ultima utilizare: ${formatLastUsed(a.lastUsed)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (a.isUnused) Tag("Nefolosită $days+ zile", Warn)
                                if (a.isDuplicate) Tag("Duplicat", MaterialTheme.colorScheme.secondary)
                                if (a.sizeBytes > 300L * 1024 * 1024) Tag("Mare", Bad)
                            }
                        }
                    }
                }
            }
        }
        Button(
            onClick = { confirm = true }, enabled = selected.isNotEmpty() && queue.isEmpty(),
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
        ) {
            Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(8.dp))
            Text("Dezinstalează aplicațiile selectate (${selected.size})")
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Confirmare dezinstalare") },
            text = {
                Text(
                    "Urmează să dezinstalezi ${chosen.size} aplicații (${formatSize(chosen.sumOf { it.sizeBytes })}):\n\n" +
                        chosen.take(8).joinToString("\n") { "• ${it.label}" } + (if (chosen.size > 8) "\n• …și încă ${chosen.size - 8}" else "") +
                        "\n\nAndroid îți va cere confirmarea separat pentru fiecare aplicație. Datele lor vor fi pierdute."
                )
            },
            confirmButton = { TextButton({ confirm = false; vm.startUninstall() }) { Text("Continuă") } },
            dismissButton = { TextButton({ confirm = false }) { Text("Anulează") } }
        )
    }
}
