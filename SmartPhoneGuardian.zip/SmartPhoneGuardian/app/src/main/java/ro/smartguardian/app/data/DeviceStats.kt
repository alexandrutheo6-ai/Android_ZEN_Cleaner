package ro.smartguardian.app.data

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs

data class DeviceStats(val ramTotal: Long, val ramUsed: Long, val storageTotal: Long, val storageUsed: Long) {
    val ramFraction get() = if (ramTotal > 0) ramUsed.toFloat() / ramTotal else 0f
    val storageFraction get() = if (storageTotal > 0) storageUsed.toFloat() / storageTotal else 0f

    companion object {
        fun read(ctx: Context): DeviceStats {
            val mi = ActivityManager.MemoryInfo()
            ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            val sf = StatFs(Environment.getDataDirectory().path)
            return DeviceStats(mi.totalMem, mi.totalMem - mi.availMem, sf.totalBytes, sf.totalBytes - sf.availableBytes)
        }
    }
}
