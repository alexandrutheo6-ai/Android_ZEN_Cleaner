package ro.smartguardian.app.data

fun formatSize(b: Long): String = when {
    b >= (1L shl 30) -> "%.1f GB".format(b / (1024.0 * 1024 * 1024))
    b >= (1L shl 20) -> "%.0f MB".format(b / (1024.0 * 1024))
    b >= 1024L -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}

/** ts: null = necunoscut (lipsește accesul), 0 = peste un an / niciodată. */
fun formatLastUsed(ts: Long?): String {
    if (ts == null) return "necunoscut"
    if (ts == 0L) return "peste un an / niciodată"
    val days = ((System.currentTimeMillis() - ts) / 86_400_000L).toInt()
    return when {
        days <= 0 -> "astăzi"
        days == 1 -> "ieri"
        days < 60 -> "acum $days zile"
        else -> "acum ${days / 30} luni"
    }
}
