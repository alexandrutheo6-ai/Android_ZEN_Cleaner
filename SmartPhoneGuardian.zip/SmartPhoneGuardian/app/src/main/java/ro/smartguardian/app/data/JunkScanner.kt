package ro.smartguardian.app.data

import android.content.Context
import android.os.Environment
import java.io.File

data class JunkFile(val path: String, val size: Long, val category: String)

/**
 * Caută fișiere care pot fi șterse în siguranță: cache-ul propriu, fișiere .tmp/.log/.bak,
 * miniaturi și pachete APK rămase. NU șterge nimic: doar listează. Ștergerea cere confirmare în UI.
 * (Android nu permite curățarea cache-ului altor aplicații.)
 */
object JunkScanner {
    private val tempExt = setOf("tmp", "temp", "log", "bak", "cache", "crdownload", "part", "old")

    fun scan(ctx: Context, allFiles: Boolean): List<JunkFile> {
        val out = ArrayList<JunkFile>()
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { dir ->
            dir.walkTopDown().filter { it.isFile }.forEach { out += JunkFile(it.absolutePath, it.length(), "Cache Guardian") }
        }
        if (allFiles) walk(Environment.getExternalStorageDirectory(), 0, out, intArrayOf(0))
        return out.filter { it.size > 0 }.sortedByDescending { it.size }.take(1000)
    }

    private fun walk(dir: File, depth: Int, out: MutableList<JunkFile>, counter: IntArray) {
        if (depth > 8 || counter[0] > 60_000) return
        val children = dir.listFiles() ?: return
        for (f in children) {
            counter[0]++
            if (f.isDirectory) {
                if (depth == 0 && f.name == "Android") continue
                if (f.name.startsWith(".") && f.name != ".thumbnails") continue
                walk(f, depth + 1, out, counter)
            } else {
                val ext = f.extension.lowercase()
                val cat = when {
                    f.parentFile?.name == ".thumbnails" -> "Miniaturi"
                    ext == "apk" -> "Fișiere APK"
                    ext in tempExt -> "Fișiere temporare"
                    else -> null
                }
                if (cat != null) out += JunkFile(f.absolutePath, f.length(), cat)
            }
        }
    }
}
