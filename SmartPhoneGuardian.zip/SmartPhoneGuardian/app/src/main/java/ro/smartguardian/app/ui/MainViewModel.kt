package ro.smartguardian.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ro.smartguardian.app.data.*
import ro.smartguardian.app.vpn.AdBlockVpnService
import java.io.File

data class UiState(
    val loading: Boolean = true,
    val apps: List<AppInfo> = emptyList(),
    val reports: List<AdReport> = emptyList(),
    val device: DeviceStats? = null,
    val junk: List<JunkFile> = emptyList(),
    val topUsage: List<Pair<String, Long>> = emptyList(),
    val hasUsage: Boolean = false,
    val hasAllFiles: Boolean = false,
    val health: HealthResult = HealthResult(0, emptyList())
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = Prefs(ctx)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    val selected = MutableStateFlow<Set<String>>(emptySet())
    val junkSelected = MutableStateFlow<Set<String>>(emptySet())
    val uninstallQueue = MutableStateFlow<List<String>>(emptyList())
    val themeMode = MutableStateFlow(prefs.themeMode)
    val unusedDays = MutableStateFlow(prefs.unusedDays)
    val message = MutableStateFlow<String?>(null)

    private var job: Job? = null
    private var junkInit = false

    /** Reanalizează totul (aplicații, reclame, stocare, fișiere temporare, scor). */
    fun refresh(force: Boolean = false) {
        if (force) job?.cancel() else if (job?.isActive == true) return
        job = viewModelScope.launch(Dispatchers.Default) {
            val usage = Perms.hasUsageAccess(ctx)
            val files = Perms.hasAllFiles()
            val apps = AppScanner.scan(ctx, prefs.unusedDays, usage)
            val reports = apps.mapNotNull { AdDetector.analyze(ctx, it.packageName, it.label) }
            val device = DeviceStats.read(ctx)
            val junk = JunkScanner.scan(ctx, files)
            val labels = apps.associate { it.packageName to it.label }
            val topUsage = (if (usage) AppScanner.weeklyUsage(ctx) else emptyMap())
                .entries.filter { it.key in labels && it.value > 0 }
                .sortedByDescending { it.value }.take(5).map { labels.getValue(it.key) to it.value }
            val health = Health.compute(
                device, apps, reports, junk.sumOf { it.size },
                AdBlockVpnService.running.value, usage, files, prefs.unusedDays
            )

            val pkgs = apps.map { it.packageName }.toSet()
            selected.update { it.intersect(pkgs) }
            val junkPaths = junk.map { it.path }.toSet()
            if (!junkInit) { junkSelected.value = junkPaths; junkInit = true }
            else junkSelected.update { it.intersect(junkPaths) }

            _ui.value = UiState(false, apps, reports, device, junk, topUsage, usage, files, health)
            InstallWatcher.check(ctx)
        }
    }

    // ----- aplicații -----
    fun toggle(pkg: String) = selected.update { if (pkg in it) it - pkg else it + pkg }
    fun select(pkgs: Collection<String>) = selected.update { it + pkgs }
    fun deselect(pkgs: Collection<String>) = selected.update { it - pkgs.toSet() }

    /** Pornește coada de dezinstalare: fiecare aplicație trece prin dialogul oficial Android. */
    fun startUninstall() {
        // Siguranță: doar aplicații din lista scanată (care exclude sistemul)
        val valid = _ui.value.apps.map { it.packageName }.filter { it in selected.value }
        uninstallQueue.value = valid
    }

    fun onUninstallResult() {
        uninstallQueue.update { it.drop(1) }
        if (uninstallQueue.value.isEmpty()) { selected.value = emptySet(); refresh(true) }
    }

    // ----- fișiere temporare -----
    fun toggleJunk(path: String) = junkSelected.update { if (path in it) it - path else it + path }
    fun setAllJunk(on: Boolean) { junkSelected.value = if (on) _ui.value.junk.map { it.path }.toSet() else emptySet() }

    fun deleteJunk() {
        viewModelScope.launch(Dispatchers.IO) {
            val allowed = _ui.value.junk.associateBy { it.path }   // doar ce a fost listat și confirmat
            var freed = 0L
            var n = 0
            for (p in junkSelected.value) {
                val j = allowed[p] ?: continue
                val f = File(p)
                if (f.exists() && f.delete()) { freed += j.size; n++ }
            }
            message.value = "Am șters $n fișiere (${formatSize(freed)})"
            refresh(true)
        }
    }

    // ----- setări -----
    fun setTheme(mode: Int) { prefs.themeMode = mode; themeMode.value = mode }
    fun setUnusedDays(days: Int) { prefs.unusedDays = days; unusedDays.value = days; refresh(true) }
}
