package ro.smartguardian.app

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import ro.smartguardian.app.data.InstallWatcher

class InstallWatchWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        InstallWatcher.check(applicationContext)
        return Result.success()
    }
}
