package ro.smartguardian.app.vpn

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import ro.smartguardian.app.data.Prefs
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Filtru DNS local prin VpnService. Funcționează 100% pe telefon:
 *  - prin tunel trece DOAR traficul DNS (către o adresă DNS virtuală), restul internetului merge direct;
 *  - interogările pentru domenii din blocklist primesc 0.0.0.0, restul sunt trimise serverului DNS al rețelei tale;
 *  - nu se salvează și nu se trimite nimic în altă parte, în afară de un contor de reclame blocate.
 * LIMITE: nu funcționează dacă e activ „DNS privat” (DoT) sau DNS-over-HTTPS în browser; nu blochează reclame
 * servite de pe același domeniu ca și conținutul (ex. YouTube).
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "ro.smartguardian.app.START"
        const val ACTION_STOP = "ro.smartguardian.app.STOP"
        private const val FAKE_DNS = "10.111.222.2"

        val running = MutableStateFlow(false)
        val blocked = MutableStateFlow(0L)

        fun start(ctx: Context) { ctx.startService(Intent(ctx, AdBlockVpnService::class.java).setAction(ACTION_START)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, AdBlockVpnService::class.java).setAction(ACTION_STOP)) }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    @Volatile private var active = false
    private val pool = Executors.newFixedThreadPool(8)
    private lateinit var blocklist: Blocklist
    private lateinit var prefs: Prefs
    private var upstream: InetAddress = InetAddress.getByName("1.1.1.1")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopVpn(); stopSelf(); return START_NOT_STICKY }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (active) return
        prefs = Prefs(this)
        blocklist = Blocklist(this)
        upstream = findUpstreamDns()   // citit ÎNAINTE de a porni VPN-ul

        val pfd = Builder()
            .setSession("SmartPhone Guardian")
            .addAddress("10.111.222.1", 24)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setBlocking(true)
            .establish() ?: return

        tun = pfd
        active = true
        running.value = true
        worker = Thread { loop(pfd) }.also { it.start() }
    }

    private fun stopVpn() {
        active = false
        running.value = false
        worker?.interrupt()
        runCatching { tun?.close() }
        tun = null
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); pool.shutdownNow(); super.onDestroy() }

    private fun findUpstreamDns(): InetAddress {
        val cm = getSystemService(ConnectivityManager::class.java)
        val dns = cm.getLinkProperties(cm.activeNetwork)?.dnsServers
            ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress && !it.isAnyLocalAddress }
        return dns ?: InetAddress.getByName("1.1.1.1")
    }

    // ---------------- bucla de pachete ----------------
    private fun loop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = input.read(buf)
                if (n < 0) break
                if (n > 0) handle(buf.copyOf(n), output)
            }
        } catch (e: Exception) {
            // tunel închis
        } finally {
            if (active) { stopVpn() }
        }
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        if (p.size < 28 || ((p[0].toInt() shr 4) and 0xF) != 4) return      // doar IPv4
        val ihl = (p[0].toInt() and 0xF) * 4
        if (p[9].toInt() != 17 || p.size < ihl + 8) return                   // doar UDP
        if (u16(p, ihl + 2) != 53) return                                    // doar DNS
        val udpLen = u16(p, ihl + 4)
        val end = minOf(p.size, ihl + udpLen)
        if (end <= ihl + 8) return
        val dns = p.copyOfRange(ihl + 8, end)

        val q = parseQuestion(dns)
        if (q != null && blocklist.isBlocked(q.name)) {
            val v = blocked.updateAndGet { it + 1 }
            prefs.blockedCount = v
            reply(out, p, ihl, blockedAnswer(dns, q))
        } else {
            pool.execute { forward(out, p, ihl, dns) }
        }
    }

    private fun forward(out: FileOutputStream, orig: ByteArray, ihl: Int, dns: ByteArray) {
        try {
            DatagramSocket().use { s ->
                protect(s)                       // traficul acesta NU intră în tunel
                s.soTimeout = 4000
                s.send(DatagramPacket(dns, dns.size, upstream, 53))
                val resp = ByteArray(4096)
                val rp = DatagramPacket(resp, resp.size)
                s.receive(rp)
                reply(out, orig, ihl, resp.copyOf(rp.length))
            }
        } catch (e: Exception) {
            // timeout / rețea indisponibilă: aplicația va reîncerca
        }
    }

    // ---------------- DNS ----------------
    private class Question(val name: String, val type: Int, val end: Int)

    private fun parseQuestion(d: ByteArray): Question? {
        if (d.size < 17) return null
        var pos = 12
        val sb = StringBuilder()
        while (pos < d.size) {
            val len = d[pos].toInt() and 0xFF
            if (len == 0) break
            if (len and 0xC0 != 0 || pos + len + 1 >= d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, pos + 1, len, Charsets.ISO_8859_1))
            pos += len + 1
        }
        if (pos + 5 > d.size) return null
        return Question(sb.toString(), u16(d, pos + 1), pos + 5)
    }

    /** Răspuns pentru domeniu blocat: A = 0.0.0.0, AAAA = ::, altceva = NXDOMAIN. */
    private fun blockedAnswer(q: ByteArray, qq: Question): ByteArray {
        val answer = qq.type == 1 || qq.type == 28
        val o = ByteArrayOutputStream()
        o.write(q, 0, 2)                                   // ID
        o.write(0x81); o.write(0x80 or (if (answer) 0 else 3))   // QR RD RA + RCODE
        o.write(0); o.write(1)                             // QDCOUNT
        o.write(0); o.write(if (answer) 1 else 0)          // ANCOUNT
        o.write(0); o.write(0); o.write(0); o.write(0)     // NS, AR
        o.write(q, 12, qq.end - 12)                        // întrebarea
        if (answer) {
            o.write(0xC0); o.write(0x0C)                   // nume (pointer)
            o.write(0); o.write(qq.type)
            o.write(0); o.write(1)                         // IN
            o.write(0); o.write(0); o.write(0); o.write(60) // TTL
            val rl = if (qq.type == 1) 4 else 16
            o.write(0); o.write(rl)
            repeat(rl) { o.write(0) }
        }
        return o.toByteArray()
    }

    // ---------------- IP / UDP ----------------
    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    private fun reply(out: FileOutputStream, orig: ByteArray, ihl: Int, payload: ByteArray) {
        val total = 28 + payload.size
        val a = ByteArray(total)
        a[0] = 0x45; a[1] = 0
        a[2] = (total shr 8).toByte(); a[3] = total.toByte()
        a[6] = 0x40; a[8] = 64; a[9] = 17
        System.arraycopy(orig, 16, a, 12, 4)               // sursa = fosta destinație
        System.arraycopy(orig, 12, a, 16, 4)
        val cs = checksum(a, 0, 20)
        a[10] = (cs shr 8).toByte(); a[11] = cs.toByte()
        a[20] = orig[ihl + 2]; a[21] = orig[ihl + 3]       // port sursă = 53
        a[22] = orig[ihl]; a[23] = orig[ihl + 1]
        val ul = 8 + payload.size
        a[24] = (ul shr 8).toByte(); a[25] = ul.toByte()   // checksum UDP = 0 (permis în IPv4)
        System.arraycopy(payload, 0, a, 28, payload.size)
        synchronized(out) { out.write(a) }
    }

    private fun checksum(a: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i < off + len - 1) {
            sum += ((a[i].toInt() and 0xFF) shl 8) or (a[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
