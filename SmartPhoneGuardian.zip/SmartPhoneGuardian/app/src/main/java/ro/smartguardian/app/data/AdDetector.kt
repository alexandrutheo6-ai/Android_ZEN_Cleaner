package ro.smartguardian.app.data

import android.content.Context
import android.content.pm.PackageManager

data class AdReport(
    val packageName: String,
    val label: String,
    val adNetworks: List<String>,
    val trackers: List<String>,
    val hasBilling: Boolean,
    val hasAdId: Boolean,
    val sensitivePermissions: List<String>
) {
    val hasAds get() = adNetworks.isNotEmpty()
    val riskScore get() = adNetworks.size * 3 + trackers.size * 2 + sensitivePermissions.size + (if (hasBilling) 1 else 0)
}

/**
 * Detectează local (fără internet) SDK-uri de reclame/trackere după componentele
 * declarate în manifestul aplicației, plus permisiuni relevante.
 * LIMITĂ: nu poate vedea codul intern al aplicației; poate omite SDK-uri fără componente declarate.
 */
object AdDetector {
    private val adSdks = listOf(
        "com.google.android.gms.ads" to "Google AdMob",
        "com.google.ads" to "Google Ads",
        "com.facebook.ads" to "Meta Audience Network",
        "com.unity3d.ads" to "Unity Ads",
        "com.unity3d.services" to "Unity Ads",
        "com.applovin" to "AppLovin",
        "com.ironsource" to "ironSource",
        "com.vungle" to "Vungle",
        "com.chartboost" to "Chartboost",
        "com.inmobi" to "InMobi",
        "com.mopub" to "MoPub",
        "com.startapp" to "StartApp",
        "com.adcolony" to "AdColony",
        "com.bytedance.sdk.openadsdk" to "Pangle (TikTok)",
        "com.mbridge" to "Mintegral",
        "com.fyber" to "Fyber",
        "com.smaato" to "Smaato",
        "com.pubmatic" to "PubMatic",
        "com.yandex.mobile.ads" to "Yandex Ads",
        "com.my.target" to "myTarget",
        "com.tapjoy" to "Tapjoy",
        "com.amazon.device.ads" to "Amazon Ads",
        "com.appnext" to "Appnext",
        "com.digitalturbine" to "Digital Turbine",
        "com.bidmachine" to "BidMachine",
        "io.bidmachine" to "BidMachine"
    )
    private val trackerSdks = listOf(
        "com.google.android.gms.measurement" to "Google Analytics / Firebase",
        "com.google.firebase.analytics" to "Firebase Analytics",
        "com.appsflyer" to "AppsFlyer",
        "com.adjust.sdk" to "Adjust",
        "com.flurry" to "Flurry",
        "io.branch" to "Branch",
        "com.mixpanel" to "Mixpanel",
        "com.amplitude" to "Amplitude",
        "com.kochava" to "Kochava",
        "com.singular" to "Singular",
        "com.facebook.FacebookActivity" to "Facebook SDK",
        "com.facebook.CustomTabActivity" to "Facebook SDK",
        "com.braze" to "Braze",
        "com.appboy" to "Braze",
        "com.segment" to "Segment"
    )
    private val sensitive = listOf(
        "android.permission.READ_CONTACTS" to "Contacte",
        "android.permission.ACCESS_FINE_LOCATION" to "Locație precisă",
        "android.permission.ACCESS_COARSE_LOCATION" to "Locație aproximativă",
        "android.permission.RECORD_AUDIO" to "Microfon",
        "android.permission.CAMERA" to "Cameră",
        "android.permission.READ_SMS" to "SMS",
        "android.permission.READ_CALL_LOG" to "Jurnal apeluri",
        "android.permission.READ_PHONE_STATE" to "Stare telefon",
        "android.permission.READ_CALENDAR" to "Calendar"
    )

    fun analyze(ctx: Context, pkg: String, label: String): AdReport? {
        val pm = ctx.packageManager
        val flags = PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or
            PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS or
            PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA
        val info = pm.pkgInfo(pkg, flags) ?: return null

        val names = ArrayList<String>()
        names += info.activities?.mapNotNull { it.name }.orEmpty()
        names += info.services?.mapNotNull { it.name }.orEmpty()
        names += info.receivers?.mapNotNull { it.name }.orEmpty()
        names += info.providers?.mapNotNull { it.name }.orEmpty()

        val ads = LinkedHashSet<String>()
        val trackers = LinkedHashSet<String>()
        for (n in names) {
            adSdks.firstOrNull { n.startsWith(it.first) }?.let { ads += it.second }
            trackerSdks.firstOrNull { n.startsWith(it.first) }?.let { trackers += it.second }
        }
        if (info.applicationInfo?.metaData?.containsKey("com.google.android.gms.ads.APPLICATION_ID") == true) {
            ads += "Google AdMob"
        }
        val perms = info.requestedPermissions?.toSet().orEmpty()
        return AdReport(
            packageName = pkg,
            label = label,
            adNetworks = ads.toList(),
            trackers = trackers.toList(),
            hasBilling = "com.android.vending.BILLING" in perms,
            hasAdId = "com.google.android.gms.permission.AD_ID" in perms,
            sensitivePermissions = sensitive.filter { it.first in perms }.map { it.second }
        )
    }
}
