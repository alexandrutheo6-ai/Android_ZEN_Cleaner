package ro.smartguardian.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ro.smartguardian.app.data.Perms
import ro.smartguardian.app.data.RecAction
import ro.smartguardian.app.ui.*

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val mode by vm.themeMode.collectAsStateWithLifecycle()
            val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            DisposableEffect(dark) {
                val t = android.graphics.Color.TRANSPARENT
                val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            GuardianTheme(dark) { GuardianRoot(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()   // reanalizează la revenirea din setări / dezinstalare
    }
}

private data class Dest(val route: String, val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GuardianRoot(vm: MainViewModel) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val msg by vm.message.collectAsStateWithLifecycle()
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) { notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.message.value = null } }

    val dests = listOf(
        Dest("home", "Acasă", Icons.Rounded.Home),
        Dest("apps", "Aplicații", Icons.Rounded.Apps),
        Dest("ads", "Reclame", Icons.Rounded.Shield),
        Dest("optimize", "Optimizare", Icons.Rounded.Speed),
        Dest("settings", "Setări", Icons.Rounded.Settings)
    )
    val route = nav.currentBackStackEntryAsState().value?.destination?.route

    fun go(r: String) = nav.navigate(r) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    val onAction: (RecAction) -> Unit = {
        when (it) {
            RecAction.APPS -> go("apps")
            RecAction.ADS -> go("ads")
            RecAction.JUNK -> go("optimize")
            RecAction.USAGE_ACCESS -> Perms.openUsageSettings(ctx)
            RecAction.ALL_FILES -> Perms.openAllFilesSettings(ctx)
            RecAction.NONE -> {}
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                dests.forEach { d ->
                    NavigationBarItem(
                        selected = route == d.route, onClick = { go(d.route) },
                        icon = { Icon(d.icon, null) }, label = { Text(d.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { DashboardScreen(vm, ::go, onAction) }
            composable("apps") { AppsScreen(vm) }
            composable("ads") { AdsScreen(vm) }
            composable("optimize") { OptimizeScreen(vm, onAction) }
            composable("settings") { SettingsScreen(vm) }
        }
    }
}
