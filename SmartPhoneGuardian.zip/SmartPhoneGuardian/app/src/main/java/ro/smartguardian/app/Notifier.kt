package ro.smartguardian.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import ro.smartguardian.app.data.AdReport

object Notifier {
    private const val CH = "install_warnings"

    fun createChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Avertizări la instalare", NotificationManager.IMPORTANCE_DEFAULT))
    }

    /** Avertizare după instalare. Utilizatorul poate păstra aplicația sau o poate dezinstala. */
    fun warn(ctx: Context, r: AdReport) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return

        val parts = ArrayList<String>()
        if (r.hasAds) parts += "Conține reclame (${r.adNetworks.joinToString()})"
        if (r.trackers.isNotEmpty()) parts += "${r.trackers.size} trackere (${r.trackers.joinToString()})"
        if (r.hasBilling) parts += "Posibile achiziții în aplicație / abonamente"
        if (r.sensitivePermissions.isNotEmpty()) parts += "Cere acces la: ${r.sensitivePermissions.joinToString()}"

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val del = PendingIntent.getActivity(
            ctx, r.packageName.hashCode(),
            Intent(Intent.ACTION_DELETE, Uri.parse("package:${r.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
        )
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("${r.label} tocmai a fost instalată")
            .setContentText(parts.firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(parts.joinToString("\n")))
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "Păstrează", open)
            .addAction(0, "Dezinstalează", del)
            .build()
        nm.notify(r.packageName.hashCode(), n)
    }
}
