package ro.smartguardian.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.smartguardian.app.data.Perms
import ro.smartguardian.app.data.RecAction
import ro.smartguardian.app.data.formatSize
import java.io.File

@Composable
fun OptimizeScreen(vm: MainViewModel, onAction: (RecAction) -> Unit) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val sel by vm.junkSelected.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    val chosen = ui.junk.filter { it.path in sel }
    val d = ui.device

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { ScreenTitle("Optimizare", "Memorie, stocare și fișiere temporare") }
                IconButton({ vm.refresh(true) }) { Icon(Icons.Rounded.Refresh, "Reanalizează") }
            }
        }
        if (ui.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (d != null) item {
            GCard(Modifier.fillMaxWidth()) {
                UsageBar("Memorie RAM", d.ramFraction, "${formatSize(d.ramUsed)} folosit din ${formatSize(d.ramTotal)}")
                Spacer(Modifier.height(14.dp))
                UsageBar("Stocare", d.storageFraction, "${formatSize(d.storageUsed)} ocupat din ${formatSize(d.storageTotal)}")
            }
        }
        item {
            GCard(Modifier.fillMaxWidth()) {
                Text("Aplicații care consumă mult", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                if (!ui.hasUsage) {
                    Text("Acordă „Acces la utilizare” pentru a vedea timpul petrecut în aplicații.", fontSize = 13.sp)
                    TextButton({ Perms.openUsageSettings(ctx) }) { Text("Deschide setările") }
                } else {
                    Text("Cel mai mult folosite (7 zile)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ui.topUsage.forEach { (name, ms) -> Text("• $name — ${ms / 3_600_000L} h ${(ms / 60_000L) % 60} min") }
                    if (ui.topUsage.isEmpty()) Text("Nu există date încă.", fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text("Cele mai mari ca spațiu", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ui.apps.take(5).forEach { Text("• ${it.label} — ${formatSize(it.sizeBytes)}") }
                Spacer(Modifier.height(6.dp))
                Text("Android nu permite aplicațiilor să vadă consumul de RAM/baterie al altor aplicații; folosesc timpul de utilizare și spațiul ocupat.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            GCard(Modifier.fillMaxWidth()) {
                Text("Fișiere temporare și APK-uri", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (!ui.hasAllFiles) {
                    Text("Acum caut doar în cache-ul propriu. Acordă acces la fișiere pentru a găsi APK-uri vechi, .tmp, .log și miniaturi.", fontSize = 13.sp)
                    TextButton({ Perms.openAllFilesSettings(ctx) }) { Text("Acordă acces la fișiere") }
                }
                val byCat = ui.junk.groupBy { it.category }
                byCat.forEach { (c, l) -> Text("• $c: ${l.size} fișiere, ${formatSize(l.sumOf { it.size })}", fontSize = 13.sp) }
                if (ui.junk.isEmpty() && !ui.loading) Text("Nu am găsit nimic de curățat.", fontSize = 13.sp)
                if (ui.junk.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton({ vm.setAllJunk(sel.size != ui.junk.size) }) { Text(if (sel.size == ui.junk.size) "Deselectează" else "Selectează toate") }
                        Button({ confirm = true }, enabled = chosen.isNotEmpty()) {
                            Icon(Icons.Rounded.CleaningServices, null); Spacer(Modifier.width(6.dp))
                            Text("Șterge (${formatSize(chosen.sumOf { it.size })})")
                        }
                    }
                }
            }
        }
        items(ui.junk.take(200), key = { it.path }) { j ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(j.path in sel, { vm.toggleJunk(j.path) })
                Column(Modifier.weight(1f)) {
                    Text(File(j.path).name, maxLines = 1, fontSize = 14.sp)
                    Text("${j.category} • ${File(j.path).parent ?: ""}", maxLines = 1, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(formatSize(j.size), fontSize = 13.sp)
            }
        }
        item { Text("Recomandări", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        items(ui.health.recommendations) { r ->
            GCard(Modifier.fillMaxWidth(), onClick = { onAction(r.action) }) {
                Text(r.title, fontWeight = FontWeight.SemiBold)
                Text(r.detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Confirmare ștergere") },
            text = { Text("Vei șterge definitiv ${chosen.size} fișiere (${formatSize(chosen.sumOf { it.size })}). Acțiunea nu poate fi anulată. Verifică lista bifată înainte de a continua.") },
            confirmButton = { TextButton({ confirm = false; vm.deleteJunk() }) { Text("Șterge") } },
            dismissButton = { TextButton({ confirm = false }) { Text("Anulează") } }
        )
    }
}
