package ro.smartguardian.app.data

import android.content.Context

/** Setări locale (SharedPreferences). Nu părăsesc telefonul. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("guardian_prefs", Context.MODE_PRIVATE)

    /** 0 = sistem, 1 = luminos, 2 = întunecat */
    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** După câte zile fără utilizare o aplicație e considerată nefolosită. */
    var unusedDays: Int
        get() = sp.getInt("unused_days", 30)
        set(v) { sp.edit().putInt("unused_days", v).apply() }

    var blockedCount: Long
        get() = sp.getLong("blocked", 0L)
        set(v) { sp.edit().putLong("blocked", v).apply() }

    /** Aplicațiile cunoscute la ultima verificare (null = prima rulare). */
    var knownPackages: Set<String>?
        get() = sp.getStringSet("known", null)?.toSet()
        set(v) { sp.edit().putStringSet("known", v?.toHashSet()).apply() }
}
