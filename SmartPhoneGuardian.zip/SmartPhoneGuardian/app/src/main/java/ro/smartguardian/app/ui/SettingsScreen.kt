package ro.smartguardian.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.smartguardian.app.data.Perms

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val mode by vm.themeMode.collectAsStateWithLifecycle()
    val days by vm.unusedDays.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("Setări")
        GCard(Modifier.fillMaxWidth()) {
            Text("Temă", fontWeight = FontWeight.Bold)
            listOf("Urmează sistemul", "Luminos", "Întunecat").forEachIndexed { i, t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == i, { vm.setTheme(i) }); Text(t)
                }
            }
        }
        GCard(Modifier.fillMaxWidth()) {
            Text("Aplicație nefolosită după", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(14, 30, 60, 90).forEach { d -> FilterChip(days == d, { vm.setUnusedDays(d) }, label = { Text("$d zile") }) }
            }
        }
        GCard(Modifier.fillMaxWidth()) {
            Text("Permisiuni speciale", fontWeight = FontWeight.Bold)
            PermRow("Acces la utilizare", "Ultima utilizare și dimensiunea aplicațiilor", ui.hasUsage) { Perms.openUsageSettings(ctx) }
            PermRow("Acces la toate fișierele", "Găsirea APK-urilor și a fișierelor temporare", ui.hasAllFiles) { Perms.openAllFilesSettings(ctx) }
        }
        GCard(Modifier.fillMaxWidth()) {
            Text("Confidențialitate", fontWeight = FontWeight.Bold)
            Text(
                "SmartPhone Guardian nu conține reclame, abonamente sau analitice. Toată analiza se face pe telefon. " +
                    "Permisiunea INTERNET este folosită doar pentru a trimite cererile DNS permise către serverul DNS al rețelei tale. " +
                    "Aplicația nu ocolește Family Link sau protecțiile Android: dezinstalările trec prin dialogul oficial al sistemului.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (granted) Tag("Acordat", Good) else OutlinedButton(onClick) { Text("Acordă") }
    }
}
