package ro.smartguardian.app.data

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.Settings

/** Compatibilitate între API-urile PackageManager (Android 12 → 16). */
@Suppress("DEPRECATION")
fun PackageManager.installedApps(): List<ApplicationInfo> =
    if (Build.VERSION.SDK_INT >= 33) getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
    else getInstalledApplications(0)

@Suppress("DEPRECATION")
fun PackageManager.pkgInfo(pkg: String, flags: Int): PackageInfo? = try {
    if (Build.VERSION.SDK_INT >= 33) getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags.toLong()))
    else getPackageInfo(pkg, flags)
} catch (e: Exception) { null }

/** Verificări și deschiderea ecranelor de permisiuni speciale. */
object Perms {
    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasAllFiles(): Boolean = Environment.isExternalStorageManager()

    fun openUsageSettings(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openAllFilesSettings(ctx: Context) {
        val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
