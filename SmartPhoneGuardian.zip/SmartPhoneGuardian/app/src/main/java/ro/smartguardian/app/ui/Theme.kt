package ro.smartguardian.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF2DD4BF), onPrimary = Color(0xFF04201C),
    secondary = Color(0xFF60A5FA), onSecondary = Color(0xFF04132B),
    background = Color(0xFF0A1020), onBackground = Color(0xFFE6EDF7),
    surface = Color(0xFF121B2F), onSurface = Color(0xFFE6EDF7),
    surfaceVariant = Color(0xFF1E2A44), onSurfaceVariant = Color(0xFF9FB0CC),
    surfaceContainer = Color(0xFF0F1729), primaryContainer = Color(0xFF134E4A), onPrimaryContainer = Color(0xFFCCFBF1),
    secondaryContainer = Color(0xFF1E3A5F), onSecondaryContainer = Color(0xFFDBEAFE),
    error = Color(0xFFF87171), outline = Color(0xFF3B4A68)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F8F7E), onPrimary = Color.White,
    secondary = Color(0xFF2563EB), onSecondary = Color.White,
    background = Color(0xFFF3F6FB), onBackground = Color(0xFF0F172A),
    surface = Color.White, onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE3EAF5), onSurfaceVariant = Color(0xFF475569),
    surfaceContainer = Color.White, primaryContainer = Color(0xFFCCFBF1), onPrimaryContainer = Color(0xFF042F2A),
    secondaryContainer = Color(0xFFDBEAFE), onSecondaryContainer = Color(0xFF0B2A66),
    error = Color(0xFFDC2626), outline = Color(0xFFCBD5E1)
)

@Composable
fun GuardianTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = Typography(), content = content)
}
