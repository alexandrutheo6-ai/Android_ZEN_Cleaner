package ro.smartguardian.app.data

enum class RecAction { NONE, APPS, ADS, JUNK, USAGE_ACCESS, ALL_FILES }
data class Recommendation(val title: String, val detail: String, val action: RecAction)
data class HealthResult(val score: Int, val recommendations: List<Recommendation>)

/** Calculează scorul de sănătate (0–100) și recomandările, doar din date locale. */
object Health {
    fun compute(
        d: DeviceStats?, apps: List<AppInfo>, reports: List<AdReport>,
        junkBytes: Long, vpnOn: Boolean, hasUsage: Boolean, hasAllFiles: Boolean, unusedDays: Int
    ): HealthResult {
        var score = 100
        val recs = ArrayList<Recommendation>()

        if (d != null) {
            val s = d.storageFraction
            val pct = (s * 100).toInt()
            if (s > 0.9f) { score -= 25; recs += Recommendation("Stocare aproape plină", "Ai ocupat $pct% din spațiu. Dezinstalează aplicații nefolosite sau șterge fișiere.", RecAction.APPS) }
            else if (s > 0.75f) { score -= 12; recs += Recommendation("Stocare ocupată", "Ai ocupat $pct% din spațiu. Merită să faci loc.", RecAction.APPS) }
            if (d.ramFraction > 0.85f) { score -= 8; recs += Recommendation("Memorie RAM ridicată", "RAM-ul e folosit în proporție de ${(d.ramFraction * 100).toInt()}%. Repornește telefonul sau închide aplicațiile nefolosite.", RecAction.NONE) }
        }

        val unused = apps.count { it.isUnused }
        if (!hasUsage) {
            score -= 5
            recs += Recommendation("Acordă „Acces la utilizare”", "Fără el nu pot afla ultima utilizare și dimensiunea exactă a aplicațiilor.", RecAction.USAGE_ACCESS)
        } else if (unused > 0) {
            score -= minOf(20, unused * 2)
            recs += Recommendation("$unused aplicații nefolosite", "Nu le-ai deschis de peste $unusedDays zile. Eliberezi ${formatSize(apps.filter { it.isUnused }.sumOf { it.sizeBytes })}.", RecAction.APPS)
        }
        val dups = apps.count { it.isDuplicate }
        if (dups > 0) recs += Recommendation("Aplicații duplicate", "$dups aplicații au același nume. Verifică dacă ai nevoie de ambele.", RecAction.APPS)

        if (junkBytes > 200L * 1024 * 1024) score -= 10 else if (junkBytes > 50L * 1024 * 1024) score -= 5
        if (junkBytes > 20L * 1024 * 1024) recs += Recommendation("Fișiere temporare", "Poți elibera ${formatSize(junkBytes)} din fișiere temporare și APK-uri.", RecAction.JUNK)
        if (!hasAllFiles) recs += Recommendation("Acordă acces la fișiere", "Pentru a găsi APK-uri vechi și fișiere temporare din stocare.", RecAction.ALL_FILES)

        val withAds = reports.count { it.hasAds }
        if (!vpnOn) { score -= 10; recs += Recommendation("Blocarea reclamelor e oprită", "Pornește filtrul DNS local pentru a bloca reclame și trackere.", RecAction.ADS) }
        if (withAds > 0) { score -= minOf(10, withAds); recs += Recommendation("$withAds aplicații conțin reclame", "Vezi detaliile și decide ce păstrezi.", RecAction.ADS) }

        return HealthResult(score.coerceIn(0, 100), recs)
    }
}
