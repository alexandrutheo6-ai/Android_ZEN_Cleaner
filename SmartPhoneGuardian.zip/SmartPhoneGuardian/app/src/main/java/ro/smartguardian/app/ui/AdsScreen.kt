package ro.smartguardian.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.smartguardian.app.data.AdReport
import ro.smartguardian.app.vpn.AdBlockVpnService

@Composable
fun AdsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val on by AdBlockVpnService.running.collectAsStateWithLifecycle()
    val blocked by AdBlockVpnService.blocked.collectAsStateWithLifecycle()
    var onlyAds by rememberSaveable { mutableStateOf(true) }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) AdBlockVpnService.start(ctx)
    }
    val list = remember(ui.reports, onlyAds) {
        ui.reports.filter { !onlyAds || it.hasAds || it.trackers.isNotEmpty() }.sortedByDescending { it.riskScore }
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Reclame și trackere", "Blocare locală prin filtru DNS (VPN pe dispozitiv)") }
        item {
            GCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Blocare reclame", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(if (on) "Activă • $blocked cereri blocate" else "Oprită", color = if (on) Good else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = on, onCheckedChange = { want ->
                        if (want) {
                            val i = VpnService.prepare(ctx)      // dialogul de consimțământ Android pentru VPN
                            if (i != null) vpnLauncher.launch(i) else AdBlockVpnService.start(ctx)
                        } else AdBlockVpnService.stop(ctx)
                    })
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Tot filtrarea se face pe telefon; nu există server și nu se trimit date. Pentru rezultate bune, setează " +
                        "Setări → Rețea → DNS privat pe „Dezactivat” sau „Automat” și oprește „DNS securizat” din browser. " +
                        "Reclamele servite de pe același domeniu ca și conținutul (ex. YouTube) nu pot fi blocate astfel.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            val withAds = ui.reports.count { it.hasAds }
            Text("Aplicații analizate: $withAds din ${ui.reports.size} conțin SDK-uri de reclame", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(onlyAds, { onlyAds = true }, label = { Text("Cu reclame/trackere") })
                FilterChip(!onlyAds, { onlyAds = false }, label = { Text("Toate") })
            }
            Text(
                "Detecția se bazează pe componentele declarate de aplicații și pe permisiuni; poate omite SDK-uri ascunse. " +
                    "Achizițiile/abonamentele sunt estimate după permisiunea de facturare Google Play.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (list.isEmpty() && !ui.loading) item { Text("Nicio aplicație de afișat.") }
        items(list, key = { it.packageName }) { r -> ReportCard(r) }
    }
}

@Composable
private fun ReportCard(r: AdReport) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    GCard(Modifier.fillMaxWidth().animateContentSize(), onClick = { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppIcon(r.packageName)
            Column(Modifier.weight(1f)) {
                Text(r.label, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r.hasAds) Tag("Reclame", Bad)
                    if (r.trackers.isNotEmpty()) Tag("${r.trackers.size} trackere", Warn)
                    if (r.hasBilling) Tag("Achiziții/abonamente", MaterialTheme.colorScheme.secondary)
                }
            }
        }
        if (open) {
            Spacer(Modifier.height(10.dp))
            Detail("Rețele de reclame", r.adNetworks.joinToString().ifEmpty { "niciuna detectată" })
            Detail("Trackere", r.trackers.joinToString().ifEmpty { "niciunul detectat" })
            Detail("Achiziții în aplicație / abonamente", if (r.hasBilling) "Posibil (permisiune de facturare Google Play)" else "Nu s-a detectat")
            Detail("Colectare de date", buildString {
                if (r.hasAdId) append("ID de publicitate. ")
                append(if (r.sensitivePermissions.isEmpty()) "Nicio permisiune sensibilă." else "Acces la: ${r.sensitivePermissions.joinToString()}.")
            })
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${r.packageName}"))) }) {
                Text("Dezinstalează")
            }
        }
    }
}

@Composable
private fun Detail(title: String, value: String) {
    Column(Modifier.padding(vertical = 3.dp)) {
        Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp)
    }
}
