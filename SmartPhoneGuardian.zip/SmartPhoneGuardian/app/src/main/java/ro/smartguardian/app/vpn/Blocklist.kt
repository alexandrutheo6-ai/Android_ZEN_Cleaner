package ro.smartguardian.app.vpn

import android.content.Context

/** Listă locală de domenii de reclame/trackere (assets/blocklist.txt). Potrivire pe sufix. */
class Blocklist(ctx: Context) {
    private val domains: HashSet<String> = ctx.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
        lines.map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toHashSet()
    }

    fun isBlocked(host: String): Boolean {
        var d = host.lowercase().trimEnd('.')
        while (true) {
            if (d in domains) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}
